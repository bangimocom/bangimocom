import 'dart:async';
import 'dart:io';

import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:camera/camera.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/core/socket_handle.dart';


import 'package:flutter_html/flutter_html.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import 'Compress.dart';
class Camera extends StatefulWidget {
  @override
  _CameraState createState() => _CameraState();
}


List<CameraDescription> cameras = [];
class _CameraState extends State<Camera> with WidgetsBindingObserver {
  CameraController controller;
  String imagePath;
  bool enableAudio = true;

  int selected_camera=0;
  @override
  void initState() {
    super.initState();
    init_camera();
  }
  void init_camera() async{
    try {
      WidgetsFlutterBinding.ensureInitialized();
      cameras = await availableCameras();
    } on CameraException catch (e) {
      print(e.toString());
    }
    WidgetsBinding.instance.addObserver(this);
    print(cameras);
    if(cameras[0]!=null){
      onNewCameraSelected(cameras[0])  ;
    }

  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // App state changed before we got the chance to initialize.
    if (controller == null || !controller.value.isInitialized) {
      return;
    }
    if (state == AppLifecycleState.inactive) {
      controller?.dispose();
    } else if (state == AppLifecycleState.resumed) {
      if (controller != null) {
        onNewCameraSelected(controller.description);
      }
    }
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      body: Stack(
        children: <Widget>[
          Container(
            child:   camera_preview_widget(),
            width: double.infinity,
            height: double.infinity,

          ),

          Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[

              _take_pic_button(),
              Padding(padding: EdgeInsets.only(bottom: 20),child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  camera_select_widget(),

                  Text('   '),
                ],
              ),)
            ],
          ),
        ],
      ),
    );
  }

  /// Display the preview from the camera (or a message if the preview is not available).
  Widget camera_preview_widget() {
    if (controller == null || !controller.value.isInitialized) {
      return CircularProgressIndicator();
    } else {
      return AspectRatio(
        aspectRatio: controller.value.aspectRatio,
        child: CameraPreview(controller),
      );
    }
  }

  /// Display the control bar with buttons to take pictures and record videos.
  Widget _take_pic_button() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      mainAxisSize: MainAxisSize.max,
      children: <Widget>[
        Container(height: 80,width: 80,padding: EdgeInsets.all(3),
          decoration: BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(200)),
              border: Border.all(color: Colors.white,width: 2)),
child: InkWell(child:
Container(height: 50,width: 50,
  decoration: BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(200)),color: Colors.white),

),onTap: (){
  controller != null &&
      controller.value.isInitialized &&
      !controller.value.isRecordingVideo
      ? onTakePictureButtonPressed()
      : null;
}
  ,),
        )
        ,
      ],
    );
  }

  /// Display a row of toggle to select the camera (or a message if no camera is available).
  Widget camera_select_widget() {
    final List<Widget> toggles = <Widget>[];

    if (cameras.isEmpty) {
      return const Text('No camera found');
    } else {
     return InkWell(child: Icon(Icons.replay_circle_filled,size: 50,color: Colors.white,),onTap: (){


       // controller != null && controller.value.isRecordingVideo  ? null
       //     :
       if(selected_camera ==0){
         selected_camera=1;
       }else{
         selected_camera=0;

       }
       onNewCameraSelected(cameras[selected_camera  ]);
     },);
    }

    return Row(children: toggles);
  }

  String timestamp() => DateTime.now().millisecondsSinceEpoch.toString();

  void showInSnackBar(String message) {
    _scaffoldKey.currentState.showSnackBar(SnackBar(content: Text(message)));
  }

  void onNewCameraSelected(CameraDescription cameraDescription) async {
     print('cameraDescription'+cameraDescription.lensDirection.index.toString());
    if (controller != null) {
      await controller.dispose();
    }
    controller = CameraController(
      cameraDescription,
      ResolutionPreset.low,
    );

    controller.addListener(() {
      if (mounted) setState(() {});
      if (controller.value.hasError) {
        showInSnackBar('Camera error ${controller.value.errorDescription}');
      }
    });

    try {
      await controller.initialize();
    } on CameraException catch (e) {
      _showCameraException(e);
    }

    if (mounted) {
      setState(() {});
    }
  }

  void onTakePictureButtonPressed() {
    takePicture().then((String filePath) {
      if (mounted) {
        setState(() {
          imagePath = filePath;
        });
        if (filePath != null){
          showInSnackBar('Picture saved to $filePath');

          Navigator
              .of(context)
              .push(MaterialPageRoute(builder: (_) => Compress(path: filePath)));
        }
      }
    });
  }


  Future<String> takePicture() async {
    if (!controller.value.isInitialized) {
      showInSnackBar('Error: select a camera first.');
      return null;
    }
    final Directory extDir = await getExternalStorageDirectory();
    final String dirPath = '${extDir.path}/Pictures/flutter_test';
    await Directory(dirPath).create(recursive: true);
    final String filePath = '$dirPath/${timestamp()}.jpg';

    if (controller.value.isTakingPicture) {
      // A capture is already pending, do nothing.
      return null;
    }

    try {
      await controller.takePicture(filePath);
    } on CameraException catch (e) {
      _showCameraException(e);
      return null;
    }
    return filePath;
  }

  void _showCameraException(CameraException e) {

    print(e.toString());
    showInSnackBar('Error: ${e.code}\n${e.description}');
  }
}



