import 'dart:convert';
import 'dart:io';

import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/material.dart';

import 'package:path_provider/path_provider.dart';


import 'package:image/image.dart' as  imagelib;
import 'package:photofilters/photofilters.dart';

import 'pages/page1.dart';
class Compress extends StatefulWidget {
  String path;
    Compress({key,@required this.path}) : super(key: key);

  @override
  _splashState createState() => _splashState();
}

class _splashState extends State<Compress> {

  @override
  void initState() {
    resize();
    super.initState();
  }

  bool prrogress = false;
    String dirPath='';
  void resize() async {
    setState(() {
      prrogress = true;
    });
    imagelib.Image image = imagelib.decodeJpg(File(widget.path).readAsBytesSync());
    final Directory extDir = await getExternalStorageDirectory();
      String dirPath = '${extDir.path}/Pictures';
    await Directory(dirPath).create(recursive: true);
    final String filePath = '$dirPath/1234.jpg';
    // image =imagelib.copyResize(image, width: 300 );
   imageFile= await File(filePath);
    await filter_Image(context, image);
    // encodeGif  ,  encodeGifAnimation  ,  encodeJpg  , encodePng  , encodeTga

    setState(() {
      prrogress = false;
    });
  }

  File imageFile;

  Future filter_Image(context,image) async {
    image =await imagelib.copyResize(image, width: 300);
    Map imagefile = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => new PhotoFilterSelector(
          title: Text("Photo Filter "),
          image: image,
          filters: presetFiltersList,
          filename: 'sample.png',
          loader: Center(child: CircularProgressIndicator()),
          fit: BoxFit.contain,
        ),
      ),
    );
    if (imagefile != null && imagefile.containsKey('image_filtered')) {
      setState(() {
        imageFile = imagefile['image_filtered'];
      });

      print('imageFile :'+imageFile.path);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child:prrogress ? CircularProgressIndicator() :
    Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
      // Text(imageFile.path),
         Container(height: 20,),
      CircleAvatar(backgroundImage: FileImage(imageFile),radius: 100,)
      ,Container(height: 20,),
      InkWell(
        onTap: (){

          Navigator
              .of(context)
              .push(MaterialPageRoute(builder: (_) => page1()));
        },
        child: Container(
          height:50,width: 100,child: Center(child: Text('Next',style: TextStyle(color: Colors.white,fontSize: 20),),)
          ,decoration: BoxDecoration(color: Colors.blue,
            borderRadius: BorderRadius.all(Radius.circular(10))),),),

    ],)
        ,),

    );
  }
}
