import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';

import 'page2.dart';



class page1 extends StatefulWidget {
  const page1({key}) : super(key: key);

  @override
  _splashState createState() => _splashState();
}

class _splashState extends State<page1> {


  @override
  void initState() {
    super.initState();
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:Container(padding: EdgeInsets.all(20),child:
      Column(children: [
        Expanded(child:  Container(padding: EdgeInsets.all(20),child:
        SingleChildScrollView(child:  Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(height:200 ,),
            Text('Enter your product name ?',style: TextStyle(color: Colors.black,fontSize: 30),),
            Container(height:20 ,),
            Container(height:60 ,child: TextField(textDirection: TextDirection.ltr,style: TextStyle(color: Colors.black),
              keyboardType: TextInputType.name,
              decoration: InputDecoration(
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                    BorderSide(color: Colors.grey, width: 2.0)),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(5),
                  borderSide: BorderSide(color: Colors.black, width: 2.0),
                ),
                labelText: '',
                labelStyle: TextStyle(color: Colors.black),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
            ),),
            // Expanded(child: Container())


          ],) ,) )  ),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Container(width:20,),
            InkWell(
              onTap: (){
                Navigator.pop(context);
              },
              child: Container(
                height:50,width: 100,child: Center(child: Text('Back',style: TextStyle(color: Colors.grey,fontSize: 20),),)
                ,decoration: BoxDecoration(color: Colors.grey[200],
                  borderRadius: BorderRadius.all(Radius.circular(10))),),),
            Expanded(child: Container()),
            InkWell(
              onTap: (){

                Navigator
                    .of(context)
                    .push(MaterialPageRoute(builder: (_) => page2()));
              },
              child: Container(
                height:50,width: 100,child: Center(child: Text('Next',style: TextStyle(color: Colors.white,fontSize: 20),),)
                ,decoration: BoxDecoration(color: Colors.blue,
                  borderRadius: BorderRadius.all(Radius.circular(10))),),),
            Container(width:20,),
          ],)
      ],)
        ,) ,
    );
  }

}