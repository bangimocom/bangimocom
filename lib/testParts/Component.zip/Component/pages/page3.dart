import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';



class page3 extends StatefulWidget {
  const page3({key}) : super(key: key);

  @override
  _splashState createState() => _splashState();
}

class _splashState extends State<page3> {


  @override
  void initState() {
    super.initState();
  }


  DateRangePickerController _datePickerController = DateRangePickerController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:Container(padding: EdgeInsets.all(20),child:
      Column(children: [
        Expanded(child:  Container(padding: EdgeInsets.all(20),child:
        SingleChildScrollView(child:  Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(height:50 ,),
            Text('Enter your Discount product ?',style: TextStyle(color: Colors.black,fontSize: 20),),
            Container(height:20 ,),
            Container(height:60 ,child: TextField(textDirection: TextDirection.ltr,style: TextStyle(color: Colors.black),
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                    BorderSide(color: Colors.grey, width: 2.0)),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(5),
                  borderSide: BorderSide(color: Colors.black, width: 2.0),
                ),
                labelText: '',
                labelStyle: TextStyle(color: Colors.black),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
            ),),
            // Expanded(child: Container())
            Container(height:80 ,),

            Text('Discount period  ',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold
                ,fontStyle: FontStyle.italic,fontSize: 20),),
            Container(height:20 ,),
            SfDateRangePicker(
              view: DateRangePickerView.month,confirmText: '',cancelText: '',
              monthViewSettings: DateRangePickerMonthViewSettings(firstDayOfWeek: 6),
              selectionMode: DateRangePickerSelectionMode.multiRange,
              //onSelectionChanged: _onSelectionChanged,
              showActionButtons: true,
              controller: _datePickerController,
              onSubmit: (Object val) {
                print(val);
              },
              onCancel: () {
                _datePickerController.selectedRanges = null;
              },
            )

          ],) ,) )  ),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Container(width:20,),
            InkWell(
              onTap: (){
                Navigator.pop(context);
              },
              child: Container(
                height:50,width: 100,child: Center(child: Text('Back',style: TextStyle(color: Colors.grey,fontSize: 20),),)
                ,decoration: BoxDecoration(color: Colors.grey[200],
                  borderRadius: BorderRadius.all(Radius.circular(10))),),),
            Expanded(child: Container()),
            InkWell(
              onTap: (){

                // Navigator
                //     .of(context)
                //     .push(MaterialPageRoute(builder: (_) => page3()));
              },
              child: Container(
                height:50,width: 100,child: Center(child: Text('Confirm',style: TextStyle(color: Colors.white,fontSize: 20),),)
                ,decoration: BoxDecoration(color: Colors.blue,
                  borderRadius: BorderRadius.all(Radius.circular(10))),),),
            Container(width:20,),
          ],)
      ],)
        ,) ,
    );
  }

}