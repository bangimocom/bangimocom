import 'dart:convert';
import 'dart:io';

import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import 'package:encrypt/encrypt.dart' as en;
import 'package:flutter/services.dart';
import 'package:flutter_app/testParts/Component/Compress.dart';
import 'Camera.dart';
import 'package:path_provider/path_provider.dart';


class Gallery extends StatefulWidget {
  const Gallery({key}) : super(key: key);

  @override
  _splashState createState() => _splashState();
}

class _splashState extends State<Gallery> {

  String _path;

  @override
  void initState() {
    super.initState();
  }

  void get_multi_file() async {
    try {
      _path = await FilePicker.getFilePath(type: FileType.image,);
      // type : FileType.IMAGE ,  FileType.CUSTOM ,  FileType.ANY ,  FileType.AUDIO,  FileType.VIDEO
      // fileExtension : zip , jpg , ...

    } on PlatformException catch (e) {
      print("Unsupported operation" + e.toString());
    }
    if (!mounted) return;

    if (_path != null) {
      print('_paths :' + _path.toString());

      Navigator
          .of(context)
          .push(MaterialPageRoute(builder: (_) => Compress(path: _path)));
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          InkWell(child: Text('select from gallery'), onTap: () {
            get_multi_file();
          },),
          InkWell(child: Text('take picture'), onTap: () {
            Navigator
                .of(context)
                .push(MaterialPageRoute(builder: (_) => Camera()));
          },),
        ],),),
    );
  }

}